<?php $__env->startSection('content'); ?>

<a class="btn btn-primary" href="<?php echo e(route('travel.create')); ?>">Add New</a>

<table>
    <tr>
        <th>ID</th>
        <th>Nama</th>
        <th>Kota</th>
        <th>Harga</th>
        <th>Action</th>
    </tr>

    <?php $__currentLoopData = $travel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
        <td><?php echo e($travel->id); ?></td>
        <td><?php echo e($travel->nama); ?></td>
        <td><?php echo e($travel->kota); ?></td>
        <td><?php echo e($travel->harga); ?></td>
        <td>
            <a class="btn btn-success" href="<?php echo e(route('travel.show', $travel->id)); ?>">Show</a>
            <a class="btn btn-warning" href="<?php echo e(route('travel.edit', $travel->id)); ?>">Edit</a>

            <form onclick="return confirm('are you sure?')" 
            action="<?php echo e(route('travel.destroy', $travel->id)); ?>" 
            method="post" style="display: inline;">
 <?php echo csrf_field(); ?>
 <?php echo method_field('DELETE'); ?>
 <button class="btn btn-danger">Delete</button>
        </form>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($travel->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('travel.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_travel/resources/views/travels/index.blade.php ENDPATH**/ ?>