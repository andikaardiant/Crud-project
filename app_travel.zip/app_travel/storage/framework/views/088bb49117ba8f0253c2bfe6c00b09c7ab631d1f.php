<?php $__env->startSection('content'); ?>

<form class="form" action="<?php echo e(route('travel.update', $travel->id)); ?>" method="post"
enctype="multipart/form-data">

<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>

<label for="">Nama</label><br>
<input type="text" name="nama" id="" value="<?php echo e($travel-> nama); ?>"><br>

<label for="">Kota</label><br>
<input type="text" name="kota" id="" value="<?php echo e($travel-> kota); ?>"><br>

<label for="">Harga</label><br>
<input type="text" name="harga" id="" value="<?php echo e($travel-> harga); ?>"><br>

<label for="">Upload Image</label><br>
<input type="file" name="image" id=""><br><br>

<input type="submit" value="Update" class="btn btn-primary">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('travel.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_travel/resources/views/travel/edit.blade.php ENDPATH**/ ?>