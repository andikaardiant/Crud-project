<?php $__env->startSection('content'); ?>
<h3><?php echo e($travel-> nama); ?></h3>

<td><img src="<?php echo e(Storage::url('public/images/' . $travel->image)); ?>"
        style="width:150px;"></td>
<p>Kota  : <?php echo e($travel-> kota); ?></p>
<p>Harga : <?php echo e($travel-> harga); ?></p>

<a href="<?php echo e(route('travel.index')); ?>" class="btn btn-secondary">Back to Index</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('travel.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_travel/resources/views/travel/show.blade.php ENDPATH**/ ?>