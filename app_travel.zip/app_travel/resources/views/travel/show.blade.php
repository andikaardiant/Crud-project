@extends('travel.layout')

@section('content')
<h3>{{ $travel-> nama }}</h3>

<td><img src="{{ Storage::url('public/images/' . $travel->image) }}"
        style="width:150px;"></td>
<p>Kota  : {{ $travel-> kota }}</p>
<p>Harga : {{ $travel-> harga }}</p>

<a href="{{ route('travel.index') }}" class="btn btn-secondary">Back to Index</a>
@endsection