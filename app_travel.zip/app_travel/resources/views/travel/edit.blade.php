@extends('travel.layout')

@section('content')

<form class="form" action="{{ route('travel.update', $travel->id) }}" method="post"
enctype="multipart/form-data">

@csrf
@method('PUT')

<label for="">Nama</label><br>
<input type="text" name="nama" id="" value="{{ $travel-> nama }}"><br>

<label for="">Kota</label><br>
<input type="text" name="kota" id="" value="{{ $travel-> kota }}"><br>

<label for="">Harga</label><br>
<input type="text" name="harga" id="" value="{{ $travel-> harga }}"><br>

<label for="">Upload Image</label><br>
<input type="file" name="image" id=""><br><br>

<input type="submit" value="Update" class="btn btn-primary">
</form>
@endsection