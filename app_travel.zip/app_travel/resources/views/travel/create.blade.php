@extends('travel.layout')

@section('content')
<form class="form" action="{{ route('travel.store') }}" method="post"enctype="multipart/form-data">

@csrf
<label for="">Nama</label><br>
<input type="text" name="nama" id=""><br>

<label for="">Kota</label><br>
<input type="text" name="kota" id=""><br>

<label for="">Harga</label><br> 
<input type="number" name="harga" id=""><br>

<label for="">Upload Image</label><br>
<input type="file" name="image" id=""><br><br>

<input type="submit" value="Save" class="btn btn-primary">
</form>
@endsection