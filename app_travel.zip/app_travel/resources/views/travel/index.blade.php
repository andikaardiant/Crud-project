@extends('travel.layout')

@section('content')

<a class="btn btn-primary" href="{{ route('travel.create') }}">Add New</a>

<table class='table'>
    <tr>
        <th>ID</th>
        <th>Image</th>
        <th>Nama</th>
        <th>Kota</th>
        <th>Harga</th>
        <th>Action</th>
    </tr>

    @foreach($travel as $trave)

    <tr>
        <td>{{ $trave->id }}</td>
        <td><img src="{{ Storage::url('public/images/' . $trave->image) }}"
        style="width:150px;"></td>
        <td>{{ $trave->nama }}</td>
        <td>{{ $trave->kota }}</td>
        <td>{{ $trave->harga }}</td>
        <td>
            <a class="btn btn-success" href="{{ route('travel.show', $trave->id) }}">Show</a>
            <a class="btn btn-warning" href="{{ route('travel.edit', $trave->id) }}">Edit</a>

            <form onclick="return confirm('are you sure?')" 
            action="{{ route('travel.destroy', $trave->id) }}" 
            method="post" style="display: inline;">
 @csrf
 @method('DELETE')
 <button class="btn btn-danger">Delete</button>
        </form>
        </td>
    </tr>
@endforeach
</table>
{{$travel->links()}}

@endsection