<?php
session_start();

include "koneksi.php";
$sql = "SELECT * FROM sewa";
$query = mysqli_query($koneksi, $sql);
if(!ISSET($_SESSION['login'])){
    header('location:login.php?loginbanh');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        @media print {
            #cetak{
                display: none;
            }
        }
    </style>
    <title>rentalkamera</title>
</head>
<body>
    <h1>sewa</h1>    
    <a href="tambah.php"><button id="cetak">tambah</button></a>
    <a href="logout.php"><button id="cetak">logout</button></a>
    <button onclick="window.print()" id="cetak">cetak</button>
    <table border="1">
        <tr>
            <th>Kode Sewa</th>
            <th>Kode Kamera</th>
            <th>Kode Customer</th>
            <th>Tanggal Pinjam</th>
            <th>Tanggal Kembali</th>
            <th>Total Sewa</th>
            <th id="cetak">Aksi</th>
        </tr>
        <?php
        while ($sewa = mysqli_fetch_assoc($query)){
        ?>
        <tr>
            <td><?=$sewa['kd_sewa'];?></td>
            <td><?=$sewa['kd_kamera'];?></td>
            <td><?=$sewa['kd_customer'];?></td>
            <td><?=$sewa['tgl_pinjam'];?></td>
            <td><?=$sewa['tgl_kembali'];?></td>
            <td><?=$sewa['total_sewa'];?></td>
            <td>
                <a href="edit.php?kd_sewa=<?=$sewa['kd_sewa'];?>"><button id="cetak">edit</button></a>
                <a href="hapus.php?kd_sewa=<?=$sewa['kd_sewa'];?>"><button id="cetak">hapus</button></a>
            </td>
            
        </tr>
        <?php
        }
        ?>
    </table>
</body>
</html>