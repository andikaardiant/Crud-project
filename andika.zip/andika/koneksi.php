<?php
$koneksi = mysqli_connect('localhost','root','123456','aku2');

// if($koneksi){
//     echo "y";
// } else {
//     echo "x";
// }
?>