<?php
include "koneksi.php";
$kd_sewa = $_GET['kd_sewa'];
$sql = "SELECT * FROM sewa WHERE kd_sewa = '$kd_sewa'";
$query = mysqli_query($koneksi,$sql);
while($sewa = mysqli_fetch_assoc($query)){
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>rental kamera</title>
</head>
<body>
    <h1>edit</h1>
    <form action="p_edit.php" method="post">
        <table>
            <input type="hidden" name="kd_sewa" value="<?=$sewa['kd_sewa'];?>">
            <tr>
                <td><label for="">Kode Kamera</label></td>
                <td><input type="number" name="kd_kamera" id="" value="<?=$sewa['kd_kamera'];?>"></td>
            </tr>
            <tr>
                <td><label for="">Kode Customer</label></td>
                <td><input type="number" name="kd_customer" id="" value="<?=$sewa['kd_customer'];?>"></td>
            </tr>
            <tr>
                <td><label for="">Tanggal Pinjam</label></td>
                <td><input type="date" name="tgl_pinjam" id="" value="<?=$sewa['tgl_pinjam'];?>"></td>
            </tr>
            <tr>
                <td><label for="">Tanggal Kembali</label></td>
                <td><input type="date" name="tgl_kembali" id="" value="<?=$sewa['tgl_kembali'];?>"></td>
            </tr>
            
        </table>
        <input type="submit" value="save">
    </form>
</body>
</html>
<?php
}
?>