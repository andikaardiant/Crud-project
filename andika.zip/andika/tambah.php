<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>rental kamera</title>
</head>
<body>
    <h1>tambah</h1>
    <form action="p_tmbh.php" method="post">
        <table>
            <tr>
                <td><label for="">Kode Kamera</label></td>
                <td><input type="number" name="kd_kamera" id=""></td>
            </tr>
            <tr>
                <td><label for="">Kode Customer</label></td>
                <td><input type="number" name="kd_customer" id=""></td>
            </tr>
            <tr>
                <td><label for="">Tanggal Pinjam</label></td>
                <td><input type="date" name="tgl_pinjam" id=""></td>
            </tr>
            <tr>
                <td><label for="">Tanggal Kembali</label></td>
                <td><input type="date" name="tgl_kembali" id=""></td>
            </tr>
            
        </table>
        <input type="submit" value="save">
    </form>
</body>
</html>